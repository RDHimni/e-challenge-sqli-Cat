package com.sqli.main.cat.factory;

import com.sqli.main.cat.Path;

/**
 * @author rida_dhimni
 *
 * Nov 28, 2019
 *
 * @project cat
 */

public class FactoryPath {

 public Path getInstance() {
		return new Path();
	}
	
}
