package com.sqli.main.cat;

import com.sqli.main.cat.factory.FactoryPath;

/**
 * @author rida_dhimni
 *
 * Nov 28, 2019
 *
 * @project cat
 */

public class Cat {
	
   private  Path path;
   private int l;
   
   public Cat() {
	// TODO Auto-generated constructor stub
	   this.path = new FactoryPath().getInstance();
}

	public Object path() {
		// TODO Auto-generated method stub
		return this.path.toString();
	}

	public void leap() {
           l++;
		if(l >= 4 ) this.path.ajouter("....*");
		else {
			for (int i = 0; i < l; i++) {

			     this.path.ajouter(".");


			}
			
			this.path.ajouter("*");
		   }
	
	}

}
