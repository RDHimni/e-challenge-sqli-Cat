package com.sqli.main.cat;

/**
 * @author rida_dhimni
 *
 * Nov 28, 2019
 *
 * @project cat
 */

public class Path {
	
	StringBuilder pat;

	public Path() {
		// TODO Auto-generated constructor stub
		this.pat = new StringBuilder("*");
	
	}
	
  Path	ajouter(String p){
		
	  this.pat.append(p);
	  
	  return this;
	}
  
  @Override
public String toString() {
	// TODO Auto-generated method stub
	return this.pat.toString();
}
	
	
}
